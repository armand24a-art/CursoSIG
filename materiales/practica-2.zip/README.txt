PRACTICA 2 - Proyecciones y sistemas de coordenadas
Contenido a incluir: capas de ejemplo en distintos SRC, guia de transformacion
de coordenadas en QGIS.
