PRACTICA 3 - Analisis espacial vectorial y raster
Contenido a incluir: capas de equipamientos (salud/educacion), datos
socioeconomicos, raster de elevacion para analisis de terreno.
