PRACTICA 0 - Introduccion e instalacion
Curso: Fundamentos de Razonamiento Espacial con SIG

Contenido de esta carpeta (a completar por el instructor):
- Guia de instalacion de QGIS (LTR)
- Datos de referencia: limites administrativos (shapefile)
- Guia paso a paso de la practica 0

Reemplaza este archivo y agrega tus materiales reales antes de comprimir de nuevo
la carpeta como practica-0.zip dentro de /materiales.
