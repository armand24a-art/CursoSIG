PRACTICA FINAL - Evaluacion integradora
Contenido a incluir: guia completa de la practica final, rubrica de
evaluacion (100 pts) y plantilla para la memoria explicativa (max. 2 paginas).
