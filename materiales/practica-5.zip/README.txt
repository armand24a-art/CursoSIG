PRACTICA 5 - Cartografia tematica
Contenido a incluir: plantilla de composicion de mapas (layout QGIS),
paletas de color sugeridas, checklist de elementos cartograficos.
