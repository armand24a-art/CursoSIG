PRACTICA 4 - Construccion de informacion espacial
Contenido a incluir: datos de censo, capa municipal, guia para el calculo
de densidad de poblacion y el indice de concentracion.
