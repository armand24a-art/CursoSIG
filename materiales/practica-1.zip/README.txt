PRACTICA 1 - Fundamentos de SIG y pensamiento espacial
Contenido a incluir: shapefile de comunas, tabla CSV con datos sociologicos,
guia de instrucciones para el join espacial.
